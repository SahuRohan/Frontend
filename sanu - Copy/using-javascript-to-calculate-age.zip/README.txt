A Pen created at CodePen.io. You can find this one at https://codepen.io/tipsoftheday/pen/hwFde.

 Using Javascript to calculate age based on the date of birth and the date to calculate